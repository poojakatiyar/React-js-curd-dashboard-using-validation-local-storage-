import React, { Component } from 'react';
import axios from 'axios';

import './UserReg.css';
class UserReg extends Component {



  constructor(props) {
      super(props)
      this.state = {
           title : '',
           name : '',
           email: '',
           phone_number:'',
           course_type:'',
           confirm_type:'',
           hour_appointment:'',
           agree_term:'',
           formErrors: {title: '', name: ''},
           emailValid: false,
           passwordValid: false,
           formValid: false


      }
  }

  handleUserInput (e) {
    const name = e.target.name;
    const value = e.target.value;
    this.setState({[name]: value},
                  () => { this.validateField(name, value) });
  }
  validateField(fieldName, value) {
    let fieldValidationErrors = this.state.formErrors;
    let emailValid = this.state.emailValid;
    let passwordValid = this.state.passwordValid;

    switch(fieldName) {
      case 'title':
        emailValid = value.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i);
        fieldValidationErrors.email = emailValid ? '' : ' is invalid';
        break;
      case 'name':
        passwordValid = value.length >= 6;
        fieldValidationErrors.password = passwordValid ? '': ' is too short';
        break;
      default:
        break;
    }
    this.setState({formErrors: fieldValidationErrors,
                    emailValid: emailValid,
                    passwordValid: passwordValid
                  }, this.validateForm);
  }

  validateForm() {
    this.setState({formValid: this.state.emailValid && this.state.passwordValid});
  }



    render () {
        return (
            <div className="UserReg">
            <div >
            <p  >Verify your inputs</p>
            <p>  title={this.state.title} </p>
            </div>
  <script type="text/javascript" src="../../assets/js/message.js"></script>

                      <div className="main">
                       <div className="container">
                        <form method="POST" className="appointment-form" id="appointment-form">
                            <h2>education appointment form</h2>
                            <div className="form-group-1">
                                <input type="text" name="title" id="title" placeholder="Title" onChange={(event) => this.handleUserInput(event)} value={this.state.title}/>
                                <input type="text" name="name" id="name" placeholder="Your Name" onChange={(event) => this.handleUserInput(event)} />
                                <input type="email" name="email" id="email" placeholder="Email" required />
                                <input type="number" name="phone_number" id="phone_number" placeholder="Phone number" required />
                                <div className="select-list">
                                    <select name="course_type" id="course_type">
                                        <option slected value="">Course Type</option>
                                        <option value="society">Society</option>
                                        <option value="language">Language</option>
                                    </select>
                                </div>
                            </div>
                            <div className="form-group-2">
                                <h3>How would you like to bo located ?</h3>
                                <div className="select-list">
                                    <select name="confirm_type" id="confirm_type">
                                        <option seleected value="">By phone</option>
                                        <option value="by_email">By email</option>
                                    </select>
                                </div>
                                <div className="select-list">
                                    <select name="hour_appointment" id="hour_appointment">
                                        <option seleected value="">Hours : 8am 10pm</option>
                                        <option value="9h-11h">Hours : 9am 11pm</option>
                                    </select>
                                </div>
                            </div>
                            <div className="form-check">
                                <input type="checkbox" name="agree_term" id="agree-term" className="agree-term" />
                                <label for="agree-term" className="label-agree-term"><span><span></span></span>I agree to the  <a href="#" class="term-service">Terms and Conditions</a></label>
                            </div>
                            <div className="form-submit">
                                <input type="submit" disabled={!this.state.formValid} name="submit" id="submit" className="submit" value="Request an appointment" />
                            </div>
                         <input type="button" value="click" onclick="msg()"/>

                        </form>
                    </div>

                </div>


              { /*  <script src="../../assets/vendor/jquery/jquery.min.js"></script> */}
                <script src="../../assets/js/main.js"></script>

            </div>
        );
    }
}

export default UserReg;
