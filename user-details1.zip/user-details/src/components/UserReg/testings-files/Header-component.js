import React, {Component} from 'react';
//import { Fragment } from 'react';
//import { Navbar, NavbarBrand, Nav, NavItem, NavLink } from 'reactstrap';


class HeaderComponent extends Component {
render()
{
  return(
  <p>pooja</p>
  )
}
}
export default HeaderComponent
