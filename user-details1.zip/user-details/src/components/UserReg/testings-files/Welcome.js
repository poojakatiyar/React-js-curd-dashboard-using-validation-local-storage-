import React, {Component} from 'react';
//import '../App.css';
import Radium from 'radium';


class Welcome extends Component {

  constructor() {
  super()
  this.state = {
  message : 'Welcome Vistor'
  }
  }
 changeMessage(newVal)
 {

  // this.setState({ message : 'Thanks for Subscribe'}) //Calling this.setState causes React to re-render your application and update the DOM
this.setState({
  message:'Hitesh Lalwani'
})

 }

  render()
  {


    const style={
      backgroundColor:'green',
      ':hover':{
        backgroundColor:'yellow'
      },
      '@media(min-width:500px)':
      {
        width:'450px'
      }
    };


      let styleClasses =[];
    if(this.state.message=='Hitesh Lalwani')
    {
      style.backgroundColor='red';
      style[':hover']={
        backgroundColor:'black'
      }
      styleClasses.push('bold-text');
    }
    else {
        styleClasses.push('bold-text');
      styleClasses.push('text-color');
    }


      //let styleClasses = ['bold-text','text-color'].join(' ');


    return(
      <div>
      <h1 className="App-header">
      {this.state.message}
      </h1>
      <p className={styleClasses.join(' ')}>hi test</p>
       <button style={style} onClick={this.changeMessage.bind(this,'HItesh')}>Subscribe Here</button>
      </div>
    )
  }



}
export default Radium(Welcome)
