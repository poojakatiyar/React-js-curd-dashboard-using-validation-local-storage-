import React, {Component} from 'react';
class Count extends Component {

constructor()
{
  super()
  this.state={
    count : 0
  }
}

increaseCounter()
{
  this.state.count = this.state.count+1
  console.log(this.state.count);
  this.setState({count: this.state.count})
}

render()
{
  return(
    <div>
    count = {this.state.count}
    <br></br>
    <button onClick={()=>this.increaseCounter()}>Increment</button>
    </div>
  )
}


}
export default Count
