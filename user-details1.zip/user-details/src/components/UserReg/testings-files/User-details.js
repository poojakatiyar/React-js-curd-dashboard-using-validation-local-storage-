import React from 'react';


//function UserDetails()
//{
//  return <h1>List Of User Details</h1>  //*functional component or using jsx code*//
//}

const UserDetails = props =>
{
  console.log(props);
  return (
    <div>
    <h1>Hello {props.name} &&&&&& {props.heroName}</h1>
    {props.children}
    </div>
  )

}

export default UserDetails
