import React from 'react';

const Userjsx = () =>  //*using arrow function here
{
//return (
//  <div>
  //<h1>List of data using jsx example</h1>
  //</div>
 //)
return React.createElement('div',null, React.createElement('h1',null,'List Of data without using ajax'));  //this is without using ajax

}
export default Userjsx
