import React, { Component } from 'react';

class AddDocumentComponent extends Component {
    documentData;
    constructor(props) {
        super(props);
        this.handleChange = this.handleChange.bind(this);
        this.handleFormSubmit = this.handleFormSubmit.bind(this);
        this.state = {
            user: '',
            email: '',
            password: ''
        }
    }

handleChange= (e)=> {
    this.setState({[e.target.name]:e.target.value});
}
// on form submit...
handleFormSubmit(e) {
    e.preventDefault()
   localStorage.setItem('document',JSON.stringify(this.state));
}

// React Life Cycle
componentDidMount() {
    this.documentData = JSON.parse(localStorage.getItem('document'));

    if (localStorage.getItem('document')) {
        this.setState({
            user: this.documentData.user,
           email: this.documentData.email,
           password: this.documentData.password
    })
} else {
    this.setState({
        user: '',
        email: '',
        password: ''
    })
}
}

render() {
    return (
        <div className="container">
            <form onSubmit={this.handleFormSubmit}>
                <div className="form-group">
                    <label>user</label>
                    <input type="text" name="user" className="form-control" value={this.state.user} onChange={this.handleChange} />
                </div>
                <div className="form-group">
                    <label>email</label>
                    <input type="text" name="email" className="form-control" value={this.state.email} onChange={this.handleChange} />
                </div>
                <div className="form-group">
                    <label>password</label>
                    <input type="number" name="password" className="form-control" value={this.state.password} onChange={this.handleChange} />
                </div>
                <button type="submit" className="btn btn-primary btn-block">Submit</button>
            </form>
        </div>
    )
}
}
export default AddDocumentComponent;
