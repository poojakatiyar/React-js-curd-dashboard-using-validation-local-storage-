import React, { Component } from 'react';
import { ThemeContext } from '../../contexts/ThemeContext';

import './Sitelist.css';

class Sitelist extends Component {
static contextType = ThemeContext;   //The contextType property on a class can be assigned a Context object created by React.createContext().
                                        //This lets you consume the nearest current value of that Context type using this.context.
                                       // You can reference this in any of the lifecycle methods including the render function.

  render() {
    const {isLightTheme , light , dark} = this.context;
     const theme = isLightTheme ? light : dark;
    console.log(this.context);
    return (
        <div className="sidenav" style={{ color: theme.syntax, background: theme.bg }}>
        <p>About</p>
        <p>Services</p>
        <p>Clients</p>
        <p>Contact</p>
        <p>Search</p>
        </div>

    );
  }
}

export default Sitelist;
