import React, { Component } from 'react';
import { ThemeContext } from '../../contexts/ThemeContext';

class TheamChange extends Component {
  static contextType = ThemeContext;
  render() {
    const { toggleTheme } = this.context;
    return ( <button onClick={toggleTheme}>Change side theam</button>);
  }
}

export default TheamChange;
