function msg(){
 alert("Hello Javatpoint");
}


export default msg;
