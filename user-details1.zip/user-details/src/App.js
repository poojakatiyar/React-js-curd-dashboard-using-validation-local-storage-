import React, {component} from 'react';
import logo from './logo.svg';
import './App.css';
import UserDetails from './components/testings-files/User-details'
import Userjsx from './components/testings-files/Userjsx'
import Welcome from './components/testings-files/Welcome'
import Count from './components/testings-files/Count'
import HeaderComponent from './components/testings-files/Header-component'
import Blog from './containers/Blog/Blog';
import Sitelist from './components/Sitelist/Sitelist'
import TheamChange from './components/Sitelist/TheamChange'


import ThemeContextProvider from './contexts/ThemeContext'

import Counter from './containers/Counter/Counter';
import Radium, {StyleRoot} from 'radium';
import { BrowserRouter } from 'react-router-dom';

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Blog />

        <ThemeContextProvider>
          <Sitelist />
        <TheamChange />
       </ThemeContextProvider>

      </div>
    </BrowserRouter>
    );
}

export default App;
{/*<UserDetails name ="pooja"  heroName="fourth">
<p>here is pooja data</p>
</UserDetails>
<UserDetails name ="anuj"  heroName="fivth"/>
<UserDetails name ="Rohit" heroName="six"/>
<Userjsx/>
<Welcome/>
<Count/>

<HeaderComponent/> */}
