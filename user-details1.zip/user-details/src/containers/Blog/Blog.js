import React, { Component } from 'react';
import axios from 'axios';
import { Route, NavLink } from 'react-router-dom';


import Posts from './Posts/Posts'
import FullPost from '../../components/FullPost/FullPost';
import NewPost from '../../components/NewPost/NewPost';
import UserReg from '../../components/UserReg/UserReg';
import CounterControl from '../../components/CounterControl/CounterControl';
import CounterOutput from '../../components/CounterOutput/CounterOutput';
import Form from '../../components/VaildationForm/Form';
import AddDocumentComponent from '../../components/LocalStorage/AddDocumentComponent'
import Sitelist from '../../components/Sitelist/Sitelist'
import './Blog.css';

class Blog extends Component {

    state = {
    posts : [],
    selectId : null,
    authentication : false,
    counter: 0

  }
//redux counter logic
  counterChangedHandler = ( action, value ) => {
      switch ( action ) {
          case 'inc':
              this.setState( ( prevState ) => { return { counter: prevState.counter + 1 } } )
              break;
          case 'dec':
              this.setState( ( prevState ) => { return { counter: prevState.counter - 1 } } )
              break;
          case 'add':
              this.setState( ( prevState ) => { return { counter: prevState.counter + value } } )
              break;
          case 'sub':
              this.setState( ( prevState ) => { return { counter: prevState.counter - value } } )
              break;
      }
  }

//redux counter logic
    render () {



        return (
            <div>
             <header className="navbar">
              <div id="ribbon">New Nav Bar</div>
              <div id="container">

              <nav>
              <div id="logo">
              XYZ
              </div>
              <ul>
              <li><NavLink to="/" exact >Home</NavLink></li> { /*if you add own active class name so we overwrote the class like this , activeClassName ="my-active" */}
              <li><NavLink to="/blog-list">Blog List</NavLink></li>
              <li><NavLink to="/new-post">New Post</NavLink></li>
              { /* <li><NavLink to="/:id">Edit Post</NavLink></li> */}
              <li><NavLink to="/user-reg">User Profile</NavLink></li>
              <li><NavLink to="/form-val">Form Val</NavLink></li>
                <li><NavLink to="/local-form">Form (Local storage)</NavLink></li>

              </ul>
              </nav>
              </div>
             </header>

                <section className="Posts">
                {/*  <div>
                    <CounterOutput value={this.state.counter} />
                    <CounterControl label="Increment" clicked={() => this.counterChangedHandler( 'inc' )} />
                    <CounterControl label="Decrement" clicked={() => this.counterChangedHandler( 'dec' )}  />
                    <CounterControl label="Add 5" clicked={() => this.counterChangedHandler( 'add', 5 )}  />
                    <CounterControl label="Subtract 5" clicked={() => this.counterChangedHandler( 'sub', 5 )}/>
                </div>*/ }
                  {/*   posts */ }
                </section>
                <section>

                </section>
                <section>

                </section>



                <Route path="/new-post" component={NewPost} />

                <Route render={() => <h1></h1>}/>
                <Route path="/user-reg" component={UserReg} />
                <Route path="/blog-list" component={Posts} />
                <Route path="/form-val" component={Form} />
                 <Route path="/local-form" component={AddDocumentComponent} />
                <Route path="/:id" component={FullPost} />


            </div>
        );
    }
}

export default Blog;
